/**
 * @file
 */

(function ($, Drupal, window, document, undefined) {
  $(document).ready(function () {
    $("#edit-biblio-next").addClass("element-invisible");
  });
})(jQuery, Drupal, this, this.document);
